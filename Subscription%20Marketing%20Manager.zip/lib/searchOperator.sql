select * from operator
join subscription_log using(operator_id)
where operator_id = {{textInput2.value}}
  and subscription_log.removed_at is null