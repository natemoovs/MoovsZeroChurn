select operator.*, subscription_log.lago_plan_code from operator
left join subscription_log on subscription_log.operator_id = operator.operator_id and subscription_log.removed_at is null
where (operator.operator_id = {{textInput2.value || null}})
  and subscription_log_id is null