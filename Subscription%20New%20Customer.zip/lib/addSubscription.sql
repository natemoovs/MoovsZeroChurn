insert into subscription_log(operator_id, lago_plan_code, started_at, created_at)
values({{table1.selectedRow.operator_id}}, {{select2.value}}, {{subscriptionStartDateInput.value}}, {{subscriptionStartDateInput.value}})
returning *