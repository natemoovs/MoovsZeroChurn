select * from POSTGRES_SWOOP.OPERATOR_SETTINGS
where operator_id = {{ operatorId.value }}