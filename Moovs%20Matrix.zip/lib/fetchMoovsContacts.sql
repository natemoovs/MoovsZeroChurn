SELECT
  *,
  "stripe_customer" ->> 'id' AS "stripe_customer_id"
FROM
  "swoop"."contact"
WHERE
  "stripe_customer" ->> 'id' = {{ stripeCustomerId.value }}
LIMIT
  100;