select * from swoop.operator o
  join swoop.operator_settings os on o.operator_id = os.operator_id
join swoop.operator_limit ol on o.operator_id = ol.operator_id
where o.operator_id = {{ operatorId.value }}