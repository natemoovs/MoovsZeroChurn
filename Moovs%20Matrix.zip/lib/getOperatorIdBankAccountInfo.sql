select * from swoop.stripe_financial_connections_account
where operator_id = {{ operatorId.value }}