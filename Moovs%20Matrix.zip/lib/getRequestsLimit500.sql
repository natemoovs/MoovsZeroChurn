SELECT
  *
FROM
  swoop."request"
WHERE
  "operator_id" = {{ operatorId.value }}
ORDER BY
  "created_at" DESC
LIMIT
  500;