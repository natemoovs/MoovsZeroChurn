
select * from POSTGRES_SWOOP.USER
where operator_id = {{ operatorId.value }}