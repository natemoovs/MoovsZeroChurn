INSERT INTO swoop.user_settings (
  user_id
)
VALUES (
  {{ userId }}
)