WITH NumberedStops AS (
    SELECT 
        s.TRIP_ID,
        s.DATE_TIME AS pickup_date_time,
        s.LOCATION AS pickup_address,
        ROW_NUMBER() OVER(PARTITION BY s.TRIP_ID ORDER BY s.DATE_TIME) AS row_num
    FROM 
        swoop.stop s
),
ComplexQuery AS (
    SELECT 
        req.REQUEST_ID as request_id,
        DATE(req.created_at) as request_created_at_date,
  req.created_at,
        req.order_number as order_number,
        req.stage as request_stage,
        req.gclid as request_gclid,
        req.order_type as order_type,
        req.operator_id as operator_id,
        trips.cancelled_at as trip_cancelled_at,
        trips.removed_at as trip_removed_at,
        trips.trip_id,
        DATE(ns.pickup_date_time) as pickup_date_time,
        req_analytics.query_string as request_query_string,
        (COALESCE(routes.PRICE, 0) + 
         COALESCE(routes.DRIVER_GRATUITY, 0) +
         COALESCE(routes.OTHER_AMT, 0) +
         COALESCE(routes.TAX_AMT, 0) +
         COALESCE(routes.TOLLS_AMT, 0) +
         COALESCE(routes.BASE_RATE_AMT, 0) +
         COALESCE(routes.OTHER2_AMT, 0) +
         COALESCE(routes.OTHER3_AMT, 0) +
         COALESCE(routes.MEET_GREET_AMT, 0) -
         COALESCE(routes.PROMO_DISCOUNT_AMT, 0))/100 AS total_amount
    FROM 
        swoop.request req
    JOIN 
        swoop.request_analytics req_analytics ON req.REQUEST_ID = req_analytics.REQUEST_ID
    JOIN 
        swoop.trip trips ON req.REQUEST_ID = trips.REQUEST_ID
    JOIN 
        swoop.route routes ON trips.TRIP_ID = routes.TRIP_ID
    LEFT JOIN 
        NumberedStops ns ON trips.TRIP_ID = ns.TRIP_ID AND ns.row_num = 1 -- Assuming you want the first stop as the pickup
    WHERE 
        req_analytics.query_string LIKE '%pf_business_id%'  
  AND req.operator_id = {{crmUseageTable.selectedRow.operator_id}}
)
SELECT 
    c.request_created_at_date,
  c.request_id,
    c.order_number,
    c.request_stage,
    c.request_gclid,
    c.order_type,
    c.operator_id,
    c.request_query_string,
    c.total_amount,
    c.trip_id,
    c.pickup_date_time,
    c.trip_removed_at,
    c.trip_cancelled_at
    
FROM 
    ComplexQuery c
ORDER BY 
    c.request_created_at_date DESC;