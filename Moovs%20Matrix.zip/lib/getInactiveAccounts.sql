select * from mozart.csm_combined_new
where days_since_last_identify > 14
  and moovs_lago_subscription_started_at is not null
and idb_removed_at is null