select * from swoop.contact
where operator_id = {{ operatorId.value }}