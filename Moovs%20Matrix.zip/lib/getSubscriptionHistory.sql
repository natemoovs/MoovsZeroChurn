select * from postgres_swoop.subscription_log
where operator_id = {{ operatorId.value }}