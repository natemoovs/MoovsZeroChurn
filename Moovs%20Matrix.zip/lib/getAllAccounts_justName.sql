SELECT
  p_company_name,
  MIN(HS_C_PROPERTY_NAME) as hubspot_company_name,
  MIN(LAGO_EXTERNAL_CUSTOMER_ID) as operator_id,
  MIN(da_days_since_last_assignment) as days_since_last_assignment,
  MIN(r_total_reservations_count) as all_trips_count,
  MIN(p_plan) as postgres_plan,
  MIN(P_STRIPE_ACCOUNT_ID) as stripe_account_id
FROM
  moovs.csm_moovs cn
  LEFT JOIN POSTGRES_SWOOP.USER u ON LAGO_EXTERNAL_CUSTOMER_ID = u.operator_id
WHERE
  p_company_name IS NOT NULL
  AND (
    p_company_name ilike {{ operatorSearchInput.value + '%' }}
   OR HS_C_PROPERTY_NAME ilike {{ operatorSearchInput.value + '%' }}
    OR LAGO_EXTERNAL_CUSTOMER_ID ilike {{ operatorSearchInput.value + '%' }}
    OR P_STRIPE_ACCOUNT_ID ilike {{ operatorSearchInput.value + '%' }}
    OR u.email_normalize ilike {{ operatorSearchInput.value + '%' }}
    OR u.first_name ilike {{ operatorSearchInput.value + '%' }}
  )
GROUP BY
  p_company_name
ORDER BY
  p_company_name
LIMIT
  100;