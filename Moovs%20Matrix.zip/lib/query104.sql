SELECT 
    cf.customer_feedback_id,
    cf.title,
    cf.description,
    cf.product_type,
    cf.created_at AS feedback_created_at,
    cf.updated_at AS feedback_updated_at,
    cf.path,
    
    u.user_id,
    u.first_name,
    u.last_name,
    u.email,
    u.role_slug,
    
    o.operator_id,
    o.name AS operator_name,
    o.name_slug,
    o.general_email AS operator_email,
    o.website_url,
    o.plan,

  -- Count of requests for this operator
    (SELECT COUNT(*) FROM swoop.request r WHERE r.operator_id = o.operator_id) AS request_count,
    
    -- Count of vehicles for this operator
    (SELECT COUNT(*) FROM swoop.vehicle v WHERE v.operator_id = o.operator_id) AS vehicle_count
FROM 
    swoop.customer_feedback cf
JOIN 
    swoop.user u ON cf.user_id = u.user_id
JOIN 
    swoop.operator o ON cf.operator_id = o.operator_id
WHERE 
    u.removed_at IS NULL
ORDER BY 
    cf.created_at DESC;