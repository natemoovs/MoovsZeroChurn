select 
  id as internal_id,
  operator_id,
  stripe_financial_connections_account_id as stripe_account_id,
  transaction->>'id' as transaction_id,
  (transaction->>'amount')::float / 100 as amount_usd,
  transaction->>'currency' as currency,
  transaction->>'status' as status,
  transaction->>'description' as description,
  to_timestamp((transaction->>'transacted_at')::bigint) as transaction_date,
  to_timestamp((transaction->>'updated')::bigint) as updated_date,
  created_at,
  updated_at,
  (transaction->'status_transitions'->>'posted_at') is not null as is_posted,
  (transaction->'status_transitions'->>'void_at') is not null as is_voided,
  (transaction->>'livemode')::boolean as is_live,
  transaction->>'transaction_refresh' as refresh_id,
  transaction->>'account' as stripe_account
from swoop.stripe_financial_connections_transaction
where stripe_financial_connections_account_id = {{ bankAccountSelect.value }}