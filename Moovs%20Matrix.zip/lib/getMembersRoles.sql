SELECT DISTINCT(role_slug)
FROM swoop.user;