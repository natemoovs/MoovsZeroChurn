select * from "moovsMatrixHistoryTable"
where operator_id = {{ operatorId.value }}