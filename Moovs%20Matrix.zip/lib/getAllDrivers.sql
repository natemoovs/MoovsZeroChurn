SELECT *
FROM postgres_swoop.driver d
LEFT JOIN mozart_new.driverapp_users dau
  ON d.driver_id = dau.id
WHERE d.operator_id = {{ operatorId.value }}
ORDER BY d.created_at ASC;