INSERT INTO
  swoop.user_access_permission (user_id, access_permission_id)
VALUES 
  {{ permissionKeys }}