SELECT *
FROM swoop.user
WHERE operator_id = {{ operatorId.value }}
AND removed_at IS NULL
ORDER BY last_name;