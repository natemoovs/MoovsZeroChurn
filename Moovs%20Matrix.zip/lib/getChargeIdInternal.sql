select
        stripe_payment_intent:charges:data[0]:id::STRING AS stripe_charge_id,
  *
from
  POSTGRES_SWOOP.NEW_PAYMENT
where
  stripe_charge_id = {{ customerChargesTable.selectedRow.STRIPE_CHARGE_ID }}
limit
  100