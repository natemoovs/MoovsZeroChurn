select * 
from MOZART_NEW.MOOVS_PLATFORM_CHARGES
where customer_id = {{ stripeCustomerId.value }}
order by created_date desc