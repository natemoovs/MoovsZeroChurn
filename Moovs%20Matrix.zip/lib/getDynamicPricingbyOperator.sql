
select * from swoop.rule
where operator_id = {{ operatorId.value }}
limit 100