
select * from swoop.price_zone
where operator_id = {{ operatorId.value }}
limit 100