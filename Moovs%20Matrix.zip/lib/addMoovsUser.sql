INSERT INTO swoop.user (
  first_name,
  last_name,
  email,
  email_normalize,
  mobile_phone,
  operator_id,
  invite_pending,
  phone_country_code,
  phone_country_dial_code,
  phone_country_format,
  phone_country_name,
  role_slug
)
VALUES (
  {{firstNameInput.value}},
  {{lastNameInput.value}},
  {{emailInput.value.trim()}},
  {{
  [
    emailInput.value.split('@')[0].replace(/\./g,''),
    emailInput.value.split('@')[1]
  ].join('@').trim().toLowerCase()
  }},
  {{phoneInput.value.replace(/\D/g,'')}},
  {{operatorId.value}},
  false,
  'us',
  '1',
  '+. (...) ...-....',
  'United States',
  'member'
) RETURNING *