select * from mozart.csm_combined_new
where operator_id = {{ operatorId.value }}