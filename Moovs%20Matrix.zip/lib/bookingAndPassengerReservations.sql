select * from fact.moovs_operator_reservations
  where
booking_contact_id = {{ fetchMoovsContacts.data[0].contact_id }}
or
passenger_contact_id = {{ fetchMoovsContacts.data[0].contact_id }}
