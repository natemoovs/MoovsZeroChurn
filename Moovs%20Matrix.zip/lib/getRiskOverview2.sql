-- Risk overview for selected operator (Snowflake)
select * from fact.moovs_risk_overview
where operator_id = {{ operatorId.value }}