SELECT
  np.*,
  u.first_name,
  u.last_name, 
  u.email,
  COALESCE(
    stripe_payment_intent:charges:data[0]:id::STRING,
    stripe_payment_intent:latest_charge:id::STRING
  ) AS stripe_charge_id
FROM
  postgres_swoop.new_payment np
LEFT JOIN postgres_swoop.user u 
  ON np.user_id = u.user_id 
WHERE stripe_charge_id = {{ connectedAccountCharges.selectedRow.STRIPE_CHARGE_ID }}