select * from fact.moovs_operator_reservations
where order_number = {{ orderOperatorSearchInput.value }}
limit 10