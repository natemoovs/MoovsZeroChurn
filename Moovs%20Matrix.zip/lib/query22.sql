select * from expansion.request_analytics
where label = 'ebea0ae4-15aa-11ec-a8e4-cf0abdfa3f71'