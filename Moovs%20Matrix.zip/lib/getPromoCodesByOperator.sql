
select * from swoop.promo_code
where operator_id = {{ operatorId.value }}
limit 100