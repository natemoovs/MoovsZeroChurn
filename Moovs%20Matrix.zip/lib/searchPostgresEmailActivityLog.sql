SELECT
  *
FROM
  POSTGRES_SWOOP.EMAIL_LOG
WHERE
  "TO" ILIKE '%' || {{toTextInputEmail.value}} || '%'
LIMIT
  100