SELECT
  name,
  operator_id,
  plan,
  stripe_account->>'id' AS stripe_account_id
FROM
  swoop.OPERATOR
WHERE
  name IS NOT NULL
  AND (
    name ILIKE {{ operatorSearchInput.value + '%' }}
    OR operator_id::TEXT ILIKE {{ operatorSearchInput.value + '%' }}
  )
LIMIT 100;