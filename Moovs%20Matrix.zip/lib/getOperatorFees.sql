select * from fact.lago_fees
where lago_operator_id = {{ operatorId.value }}
order by created_month desc