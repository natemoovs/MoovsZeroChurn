WITH seven_day_totals AS (
    SELECT 
        OPERATOR_NAME,
        STRIPE_ACCOUNT_ID,
        -- Total charges for the current 7 days
        SUM(CASE 
            WHEN CAST(CREATED_DATE AS DATE) >= CURRENT_DATE - INTERVAL '7 DAYS' 
                AND CAST(CREATED_DATE AS DATE) < CURRENT_DATE 
            THEN TOTAL_DOLLARS_CHARGED 
            ELSE 0 
        END) AS total_charges_current_7_days,
        -- Total charges for the previous 7 days
        SUM(CASE 
            WHEN CAST(CREATED_DATE AS DATE) >= CURRENT_DATE - INTERVAL '14 DAYS' 
                AND CAST(CREATED_DATE AS DATE) < CURRENT_DATE - INTERVAL '7 DAYS' 
            THEN TOTAL_DOLLARS_CHARGED 
            ELSE 0 
        END) AS total_charges_previous_7_days
    FROM 
        MOZART_NEW.MOOVS_PLATFORM_CHARGES
    WHERE 
        CAST(CREATED_DATE AS DATE) >= CURRENT_DATE - INTERVAL '14 DAYS'
        AND STATUS = 'succeeded'
    GROUP BY 
        OPERATOR_NAME,
        STRIPE_ACCOUNT_ID
    HAVING 
        SUM(CASE 
            WHEN CAST(CREATED_DATE AS DATE) >= CURRENT_DATE - INTERVAL '7 DAYS' 
                AND CAST(CREATED_DATE AS DATE) < CURRENT_DATE 
            THEN TOTAL_DOLLARS_CHARGED 
            ELSE 0 
        END) > 5000
        OR 
        SUM(CASE 
            WHEN CAST(CREATED_DATE AS DATE) >= CURRENT_DATE - INTERVAL '14 DAYS' 
                AND CAST(CREATED_DATE AS DATE) < CURRENT_DATE - INTERVAL '7 DAYS' 
            THEN TOTAL_DOLLARS_CHARGED 
            ELSE 0 
        END) > 5000
)
SELECT 
    t.OPERATOR_NAME,
    t.STRIPE_ACCOUNT_ID,
    csm.POSTGRES_PLAN,
    csm.operator_id,
    csm.risk_score,
    t.total_charges_current_7_days,
    t.total_charges_previous_7_days,
    -- Percentage change in total charges
    CASE
        WHEN t.total_charges_previous_7_days = 0 THEN NULL
        ELSE ((t.total_charges_current_7_days - t.total_charges_previous_7_days) / 
              t.total_charges_previous_7_days * 100)
    END AS percentage_change
FROM 
    seven_day_totals t
LEFT JOIN 
    MOZART.CSM_COMBINED_NEW csm ON t.STRIPE_ACCOUNT_ID = csm.stripe_account_id
ORDER BY 
    t.total_charges_current_7_days DESC;