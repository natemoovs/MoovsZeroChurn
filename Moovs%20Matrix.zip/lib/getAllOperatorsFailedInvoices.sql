SELECT 
   lago_invoices.customer_external_id,
    operator.POSTGRES_PLAN,
  operator.MOOVS_COMPANY_NAME,
  operator.STRIPE_ACCOUNT_ID,
    COUNT(*) AS invoice_count,
    SUM(lago_invoices.gross_amount_usd) AS total_amount,
   SUM(lago_invoices.net_amount_usd) AS net_amount,
    SUM(lago_invoices.invoice_total_usd) AS amount_due,
    MAX(lago_invoices.period_end) AS latest_payment_due_date
FROM 
    fact.lago_invoices AS lago_invoices
JOIN 
    MOZART.CSM_COMBINED_NEW AS operator
ON 
    lago_invoices.customer_external_id = operator.OPERATOR_ID
WHERE 
    lago_invoices.payment_status = 'failed'
GROUP BY 
    lago_invoices.customer_external_id, 
    operator.POSTGRES_PLAN,
  operator.MOOVS_COMPANY_NAME,
  operator.STRIPE_ACCOUNT_ID
  ORDER BY
  amount_due desc;