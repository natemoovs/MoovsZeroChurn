select * from MOZART_NEW.ALL_SUBSCRIPTIONS
where mozart_new.all_subscriptions.EXTERNAL_CUSTOMER_ID = {{ operatorId.value }}