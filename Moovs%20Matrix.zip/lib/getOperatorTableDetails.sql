select * from swoop.operator o
  join swoop.operator_settings os on o.operator_id = os.operator_id
join swoop.operator_limit ol on o.operator_id = ol.operator_id
 left join swoop.duda_website dw on dw.operator_id = o.operator_id
where o.operator_id = {{ operatorId.value }}