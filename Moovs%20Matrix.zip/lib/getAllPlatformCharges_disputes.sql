select * 
from MOZART_NEW.MOOVS_PLATFORM_CHARGES
where DISPUTE_ID is not null
  AND STRIPE_ACCOUNT_ID = {{ stripeId.value }}
order by created_date desc