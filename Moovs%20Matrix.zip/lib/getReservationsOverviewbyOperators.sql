WITH monthly_stats AS (
    -- First get monthly totals by operator
    SELECT
      r.operator_id,
      o.name AS operator_name,
      DATE_TRUNC('month', r.created_at) AS created_month,
      COUNT(*) AS total_trips,
      SUM(r.total_amount) AS total_amount
    FROM
      fact.moovs_operator_reservations r
      JOIN POSTGRES_SWOOP.operator o
      ON r.operator_id = o.operator_id
    WHERE
      -- Filter for last 6 months but exclude current month
      r.created_at >= DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '6 months'
      
    GROUP BY
      r.operator_id,
      o.name,
      DATE_TRUNC('month', r.created_at)
  ),
  ranked_operators AS (
    -- Rank operators within each month
    SELECT
      *,
      ROW_NUMBER() OVER (
        PARTITION BY
          created_month
        ORDER BY
          total_amount DESC,
          total_trips DESC
      ) AS amount_rank
    FROM
      monthly_stats
  )
  -- Get final results
SELECT
  created_month,
  operator_id,
  operator_name,
  total_trips,
  total_amount,
  amount_rank
FROM
  ranked_operators
WHERE
  amount_rank <= 10  -- Get top 10 only
ORDER BY
  created_month DESC,
  amount_rank ASC;