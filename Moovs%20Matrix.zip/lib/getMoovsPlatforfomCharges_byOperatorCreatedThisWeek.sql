SELECT 
    operator_name,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE) THEN total_dollars_charged ELSE 0 END) AS total_charged_this_week,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE) AND status = 'succeeded' THEN total_dollars_charged ELSE 0 END) AS total_succeeded_this_week,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE) AND status = 'failed' THEN total_dollars_charged ELSE 0 END) AS total_failed_this_week,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE - INTERVAL '1 week') THEN total_dollars_charged ELSE 0 END) AS total_charged_last_week,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE - INTERVAL '1 week') AND status = 'succeeded' THEN total_dollars_charged ELSE 0 END) AS total_succeeded_last_week,
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE - INTERVAL '1 week') AND status = 'failed' THEN total_dollars_charged ELSE 0 END) AS total_failed_last_week
FROM 
    mozart_new.moovs_platform_charges
WHERE 
    created_date >= DATE_TRUNC('week', CURRENT_DATE) - INTERVAL '1 week' -- Includes records from this week and last week
GROUP BY 
    operator_name
HAVING 
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE) THEN total_dollars_charged ELSE 0 END) > 9000
    OR
    SUM(CASE WHEN DATE_TRUNC('week', created_date) = DATE_TRUNC('week', CURRENT_DATE - INTERVAL '1 week') THEN total_dollars_charged ELSE 0 END) > 10000
ORDER BY 
    operator_name;