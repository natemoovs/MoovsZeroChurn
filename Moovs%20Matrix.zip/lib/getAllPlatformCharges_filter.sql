select * 
from MOZART_NEW.MOOVS_PLATFORM_CHARGES
where STRIPE_ACCOUNT_ID = {{ stripeId.value }}
and DATE_TRUNC('month', CREATED_DATE) = DATE_TRUNC('month', {{ monthlyTotalChargesbyLast3.selectedPoints[0].x }}::date)
and STATUS = {{ monthlyTotalChargesbyLast3.selectedPoints[0].dataset }}
order by CREATED_DATE desc
