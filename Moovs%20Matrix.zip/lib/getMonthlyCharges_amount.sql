WITH monthly_charges AS (
    SELECT 
        DATE_TRUNC('month', CREATED_DATE) as charge_month,
        STATUS,
        SUM(TOTAL_DOLLARS_CHARGED) as total_charges
    FROM MOZART_NEW.MOOVS_PLATFORM_CHARGES 
    WHERE STRIPE_ACCOUNT_ID = {{ stripeId.value }}
        AND CREATED_DATE >= DATEADD(month, -6, DATE_TRUNC('month', CURRENT_DATE()))
        AND CREATED_DATE < DATEADD(month, 1, DATE_TRUNC('month', CURRENT_DATE()))
    GROUP BY 
        DATE_TRUNC('month', CREATED_DATE),
        STATUS
)
SELECT 
    charge_month,
    STATUS,
    total_charges
FROM monthly_charges
ORDER BY 
    charge_month DESC,
    STATUS;