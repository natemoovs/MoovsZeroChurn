update subscription_log set removed_at = {{moment(cancellationDate.value).toISOString()}}
where operator_id = {{table1.selectedRow.operator_id}} and subscription_log_id = {{table1.selectedRow.subscription_log_id}}
