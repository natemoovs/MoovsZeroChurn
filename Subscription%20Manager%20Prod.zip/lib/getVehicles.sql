select vehicle_id, name from vehicle
where operator_id = {{table1.selectedRow.operator_id}}
and removed_at is null