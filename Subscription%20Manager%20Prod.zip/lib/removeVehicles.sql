update vehicle set removed_at = CURRENT_TIMESTAMP
where operator_id = {{table1.selectedRow.operator_id}}
and removed_at is null
and vehicle_id <> {{listbox1.value}}