update swoop.subscription_log
set
  plan_history = jsonb_insert(
    plan_history::jsonb,
    '{0}',
    json_build_object('startedAt', started_at)::jsonb
      || json_build_object('lagoPlanCode', lago_plan_code)::jsonb),
  lago_plan_code = {{select2.value}},
  started_at = CURRENT_TIMESTAMP
where subscription_log_id = {{searchOperator.data.subscription_log_id[0]}}
returning *