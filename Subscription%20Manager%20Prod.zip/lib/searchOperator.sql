select * from operator
join subscription_log using(operator_id)
where (
  case when length({{textInput2.value}}::varchar) > 0 then operator_id = {{textInput2.value}}
  when length({{textInput1.value}}::varchar) > 0 then name ilike {{textInput1.value + '%'}}
  else false end)
 -- and subscription_log.removed_at is null